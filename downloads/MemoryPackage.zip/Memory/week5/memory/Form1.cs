﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace memory
{


    public partial class formMain : Form
    {
        public formMain()
        {
            InitializeComponent();
            Random random = new Random();
            string[] memoryPairs = new string[] {"0", "1", "2", "3", "4", "5"}; // De tags die toegekend kunnen worden
            int[] memoryAmountLeft = new int[] {2, 2, 2, 2, 2, 2 }; //Hoeveel er nog van uitgedeeld kan worden

            // Voor elke picturebox die een labeltoegekend moet krijgen
            for (int i = 0; i < 12; i++)
            {
                PictureBox pb = this.Controls.Find("pbMemory"+i, true).FirstOrDefault() as PictureBox;
                int memoryIndex = random.Next(memoryPairs.Length);
                pb.Tag = null;
                while (pb.Tag == null)
                {
                    if (memoryAmountLeft[memoryIndex] > 0)
                    {   // Zet de tag
                        pb.Tag = memoryPairs[memoryIndex];

                        // Verminder hoeveel er van deze tag over is met 1
                        memoryAmountLeft[memoryIndex] -= 1;
                    }
                    else {
                        memoryIndex = random.Next(memoryPairs.Length);
                    }
                }

            } 
        }

        int clickCounter = 0;
        PictureBox previousPictureBox;
        private void memory_Click(object sender, EventArgs e)
        {
            PictureBox currentSender = sender as PictureBox;
            if (currentSender.Image == null){
                clickCounter++;
            }
            string imagePath = Application.StartupPath + @"\memory_kaarten\";
            currentSender.SizeMode = PictureBoxSizeMode.StretchImage;
            currentSender.Image = Image.FromFile(imagePath + currentSender.Tag as string + ".png");
            Application.DoEvents();

            if (clickCounter == 1){
                previousPictureBox = currentSender; // Eerst geklikte picturebox opslaan
            }
            if (clickCounter == 2) {
                if (previousPictureBox.Tag as string == currentSender.Tag as string){ // Als de memory kaarten gelijk zijn
                }
                else { // Als ze niet hetzelfde zijn de boxen terugdraaien
                    Thread.Sleep(500);
                    currentSender.Image = null;
                    previousPictureBox.Image = null;
                }
                if (clickCounter > 2) {
                    currentSender.Image = null;
                    previousPictureBox.Image = null;
                }

                clickCounter = 0;
            }

        }

    }
}
