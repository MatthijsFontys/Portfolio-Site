﻿namespace memory
{
    partial class formMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbMemory0 = new System.Windows.Forms.PictureBox();
            this.pbMemory11 = new System.Windows.Forms.PictureBox();
            this.pbMemory10 = new System.Windows.Forms.PictureBox();
            this.pbMemory9 = new System.Windows.Forms.PictureBox();
            this.pbMemory8 = new System.Windows.Forms.PictureBox();
            this.pbMemory7 = new System.Windows.Forms.PictureBox();
            this.pbMemory6 = new System.Windows.Forms.PictureBox();
            this.pbMemory5 = new System.Windows.Forms.PictureBox();
            this.pbMemory4 = new System.Windows.Forms.PictureBox();
            this.pbMemory3 = new System.Windows.Forms.PictureBox();
            this.pbMemory2 = new System.Windows.Forms.PictureBox();
            this.pbMemory1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory1)).BeginInit();
            this.SuspendLayout();
            // 
            // pbMemory0
            // 
            this.pbMemory0.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMemory0.Location = new System.Drawing.Point(10, 19);
            this.pbMemory0.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory0.Name = "pbMemory0";
            this.pbMemory0.Size = new System.Drawing.Size(150, 122);
            this.pbMemory0.TabIndex = 0;
            this.pbMemory0.TabStop = false;
            this.pbMemory0.Tag = "0";
            this.pbMemory0.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory11
            // 
            this.pbMemory11.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbMemory11.Location = new System.Drawing.Point(473, 271);
            this.pbMemory11.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory11.Name = "pbMemory11";
            this.pbMemory11.Size = new System.Drawing.Size(150, 122);
            this.pbMemory11.TabIndex = 11;
            this.pbMemory11.TabStop = false;
            this.pbMemory11.Tag = "5";
            this.pbMemory11.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory10
            // 
            this.pbMemory10.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory10.Location = new System.Drawing.Point(319, 272);
            this.pbMemory10.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory10.Name = "pbMemory10";
            this.pbMemory10.Size = new System.Drawing.Size(150, 122);
            this.pbMemory10.TabIndex = 10;
            this.pbMemory10.TabStop = false;
            this.pbMemory10.Tag = "5";
            this.pbMemory10.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory9
            // 
            this.pbMemory9.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory9.Location = new System.Drawing.Point(164, 271);
            this.pbMemory9.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory9.Name = "pbMemory9";
            this.pbMemory9.Size = new System.Drawing.Size(150, 122);
            this.pbMemory9.TabIndex = 9;
            this.pbMemory9.TabStop = false;
            this.pbMemory9.Tag = "2";
            this.pbMemory9.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory8
            // 
            this.pbMemory8.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory8.Location = new System.Drawing.Point(10, 269);
            this.pbMemory8.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory8.Name = "pbMemory8";
            this.pbMemory8.Size = new System.Drawing.Size(150, 122);
            this.pbMemory8.TabIndex = 8;
            this.pbMemory8.TabStop = false;
            this.pbMemory8.Tag = "3";
            this.pbMemory8.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory7
            // 
            this.pbMemory7.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory7.Location = new System.Drawing.Point(473, 144);
            this.pbMemory7.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory7.Name = "pbMemory7";
            this.pbMemory7.Size = new System.Drawing.Size(150, 122);
            this.pbMemory7.TabIndex = 7;
            this.pbMemory7.TabStop = false;
            this.pbMemory7.Tag = "4";
            this.pbMemory7.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory6
            // 
            this.pbMemory6.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory6.Location = new System.Drawing.Point(319, 145);
            this.pbMemory6.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory6.Name = "pbMemory6";
            this.pbMemory6.Size = new System.Drawing.Size(150, 122);
            this.pbMemory6.TabIndex = 6;
            this.pbMemory6.TabStop = false;
            this.pbMemory6.Tag = "0";
            this.pbMemory6.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory5
            // 
            this.pbMemory5.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory5.Location = new System.Drawing.Point(164, 145);
            this.pbMemory5.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory5.Name = "pbMemory5";
            this.pbMemory5.Size = new System.Drawing.Size(150, 122);
            this.pbMemory5.TabIndex = 5;
            this.pbMemory5.TabStop = false;
            this.pbMemory5.Tag = "3";
            this.pbMemory5.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory4
            // 
            this.pbMemory4.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory4.Location = new System.Drawing.Point(10, 144);
            this.pbMemory4.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory4.Name = "pbMemory4";
            this.pbMemory4.Size = new System.Drawing.Size(150, 122);
            this.pbMemory4.TabIndex = 4;
            this.pbMemory4.TabStop = false;
            this.pbMemory4.Tag = "2";
            this.pbMemory4.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory3
            // 
            this.pbMemory3.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory3.Location = new System.Drawing.Point(473, 19);
            this.pbMemory3.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory3.Name = "pbMemory3";
            this.pbMemory3.Size = new System.Drawing.Size(150, 122);
            this.pbMemory3.TabIndex = 3;
            this.pbMemory3.TabStop = false;
            this.pbMemory3.Tag = "1";
            this.pbMemory3.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory2
            // 
            this.pbMemory2.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory2.Location = new System.Drawing.Point(318, 19);
            this.pbMemory2.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory2.Name = "pbMemory2";
            this.pbMemory2.Size = new System.Drawing.Size(150, 122);
            this.pbMemory2.TabIndex = 2;
            this.pbMemory2.TabStop = false;
            this.pbMemory2.Tag = "4";
            this.pbMemory2.Click += new System.EventHandler(this.memory_Click);
            // 
            // pbMemory1
            // 
            this.pbMemory1.BackColor = System.Drawing.Color.DodgerBlue;
            this.pbMemory1.Location = new System.Drawing.Point(164, 19);
            this.pbMemory1.Margin = new System.Windows.Forms.Padding(2);
            this.pbMemory1.Name = "pbMemory1";
            this.pbMemory1.Size = new System.Drawing.Size(150, 122);
            this.pbMemory1.TabIndex = 1;
            this.pbMemory1.TabStop = false;
            this.pbMemory1.Tag = "1";
            this.pbMemory1.Click += new System.EventHandler(this.memory_Click);
            // 
            // formMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 406);
            this.Controls.Add(this.pbMemory11);
            this.Controls.Add(this.pbMemory10);
            this.Controls.Add(this.pbMemory9);
            this.Controls.Add(this.pbMemory8);
            this.Controls.Add(this.pbMemory7);
            this.Controls.Add(this.pbMemory6);
            this.Controls.Add(this.pbMemory5);
            this.Controls.Add(this.pbMemory4);
            this.Controls.Add(this.pbMemory3);
            this.Controls.Add(this.pbMemory2);
            this.Controls.Add(this.pbMemory1);
            this.Controls.Add(this.pbMemory0);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "formMain";
            this.Text = "Memory";
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMemory1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbMemory0;
        private System.Windows.Forms.PictureBox pbMemory11;
        private System.Windows.Forms.PictureBox pbMemory10;
        private System.Windows.Forms.PictureBox pbMemory9;
        private System.Windows.Forms.PictureBox pbMemory8;
        private System.Windows.Forms.PictureBox pbMemory7;
        private System.Windows.Forms.PictureBox pbMemory6;
        private System.Windows.Forms.PictureBox pbMemory5;
        private System.Windows.Forms.PictureBox pbMemory4;
        private System.Windows.Forms.PictureBox pbMemory3;
        private System.Windows.Forms.PictureBox pbMemory2;
        private System.Windows.Forms.PictureBox pbMemory1;
    }
}

