﻿using System;
using System.Collections.Generic; // Importeren van lijsten
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading; // Importeren van delay
using System.Threading.Tasks; 
using System.Windows.Forms;

namespace BoterKaasEieren_OKMON_engine
{
    public partial class Form1 : Form
    {
        //image path
        string path = Application.StartupPath + @"\images\";
        string[] boardState = new string[10];
        PictureBox[] allFields = new PictureBox[10];
        Random random = new Random();
        bool againstComputer;
        bool boardImported = false;
        bool computerBegin = false;
        string turn = "X";
        string notTurn = "O";
        Color beginColor;
        bool computerMode;

        /* Win posities
         1, 2,  3
         4, 5,  6
         1, 5,  9
        */
        readonly int[,] winPositions = new int[,] { { 1, 2, 3 }, { 4, 5, 6 }, { 1, 5, 9 } };
        public Form1()
        {
            InitializeComponent();
            tbSpeed.Text = "0";
            beginColor = btnX.BackColor;

            // Hiding developer items
            lblGameCount.Visible = false;
            tbImport.Visible = false;
            btnDebug.Visible = false;
            btnComputerMode.Visible = false;
            btnOkmonBattle.Visible = false;
            tbSpeed.Visible = false;
            lblDelay.Visible = false;
        }

        // Als er door de speler een move wordt gemaakt
        private void field_click(object sender, EventArgs e)
        {
            // Maak dit korter, maak variabele voor die niet aan de beurt is en swap die in een functie
            PictureBox clickedBox = sender as PictureBox;
            if (clickedBox.Tag as string == "empty")
                makeMove(clickedBox, false);
            // Als er nog niemand gewonnen heeft
            if (getWinner() == "" && againstComputer)
                computerMove();
        }


        /* 
         Bord draai functie
         1 naar 3
         2 naar 6
         3 naar 9
         4 naar 2
         5 naar 5
         6 naar 8
         7 naar 1
         8 naar 4
         9 naar 7
             */
        private string[] turnBoard(int turn_times)
        {
            string[] turnedBoard = new string[10] { "", "empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty" };
            string[] boardCopy = (string[])boardState.Clone();

            if (turn_times == 0)
                return boardState;

            for (int i = 0; i < turn_times; i++)
            {
                turnedBoard[3] = boardCopy[1];
                turnedBoard[6] = boardCopy[2];
                turnedBoard[9] = boardCopy[3];
                turnedBoard[2] = boardCopy[4];
                turnedBoard[5] = boardCopy[5];
                turnedBoard[8] = boardCopy[6];
                turnedBoard[1] = boardCopy[7];
                turnedBoard[4] = boardCopy[8];
                turnedBoard[7] = boardCopy[9];
                boardCopy = (string[])turnedBoard.Clone();
            }
            return turnedBoard;
        }

        private string showWinner()
        {
            // Alle win posities
            for (int j = 0; j < 3; j++)
            {
                // Draai het bord
                for (int i = 0; i < 4; i++)
                {
                    string[] board = turnBoard(i);
                    if (board[winPositions[j, 0]] == board[winPositions[j, 1]] && board[winPositions[j, 1]] == board[winPositions[j, 2]] && board[winPositions[j, 0]] != "empty")
                    {
                        writeLog(turn + " won!");
                        if (! computerMode)
                            MessageBox.Show(turn + " heeft gewonnen!");
                        if (computerMode && turn.ToUpper() == "X") {
                            MessageBox.Show("OKMON heeft verloren");
                        }
                        for (int x = 1; x <= 9; x++)
                        {
                            PictureBox pb = this.Controls.Find("pbField" + x, true).FirstOrDefault() as PictureBox;
                            pb.Tag = "disabled";
                        }
                        return lblTurn.Text;
                    }
                } // einde eerste for
            } // einde 2de for
            return "";
        }

        private string getWinner()
        {
            // Voor alle winposities
            for (int j = 0; j < 3; j++)
            {
                // Draai het bord
                for (int i = 0; i < 4; i++)
                {
                    string[] board = turnBoard(i);
                    if (board[winPositions[j, 0]] == board[winPositions[j, 1]] && board[winPositions[j, 1]] == board[winPositions[j, 2]] && board[winPositions[j, 0]] != "empty")
                    {
                        return lblTurn.Text;
                    }
                } // einde eerste for
            } // einde 2de for
            return "";
        }

        // Zorgt dat de variabele board state weer klopt met de tags van alle boxes
        private void updateBoardState()
        {
            for (int i = 1; i <= 9; i++)
            {
                PictureBox pb = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
                boardState[i] = pb.Tag as string;
            }
        }

        // Geeft een bericht met de waardes van een string[] erin, Functie om mee te testen
        private void readArray(string[] arr)
        {
            string fullArray = "";
            for (int i = 0; i < arr.Length; i++)
            {
                fullArray = fullArray + "  " + arr[i];
            }
            MessageBox.Show(fullArray);
        }

        // De zet van de OKMON engine
        private void computerMove(bool hint = false)
        {
            int winMove;
            List<int> doubleWinMoves = getDoubleWinMoves(notTurn);
            List<int> doubleWinMovesSelf = getDoubleWinMoves(turn);
            List<int> singleWinMoves = getSingleWinMoves(turn);

            if (!boardState.Contains("X"))
            { // Als het bord nog leeg is
                takeRandom(hint);
                writeLog("Random move");
            }
            else if (getWinMove(turn) > 0) // Als de computer kan winnen
            {
                winMove = getWinMove(turn);
                PictureBox pb = this.Controls.Find("pbField" + winMove, true).FirstOrDefault() as PictureBox;
                makeMove(pb, hint);
                writeLog("Winning move");
            }
            else if (getWinMove(notTurn) > 0) // Als de tegenstander kan winnen
            {
                PictureBox pb = this.Controls.Find("pbField" + getWinMove(notTurn), true).FirstOrDefault() as PictureBox;
                writeLog(turn + " - " + getWinMove(notTurn));
                makeMove(pb, hint);
                writeLog("Block win");
            }
            else if (getDoubleWinMoves(turn).Count > 0) { // Als de computer zelf 2 win kansen kan maken
                List<int> doubleWin = getDoubleWinMoves(turn);
                int r = random.Next(getDoubleWinMoves(turn).Count());
                PictureBox pb = this.Controls.Find("pbField" + doubleWin[r], true).FirstOrDefault() as PictureBox;
                writeLog(turn + " - " + doubleWin[r]);
                makeMove(pb, hint);
                writeLog("Double win");
            }
           else if (doubleWinMoves.Count > 1) // Als de tegenstander maar op 1 manier 2 winkansen kan maken
            {
                getDoubleBlockMove(turn, hint);
                writeLog("Double win block");
            }
            else if (doubleWinMoves.Count > 0) // Als er op 1 manier 2 winkans kan worden gemaakt
            {
                for (int i = 0; i < singleWinMoves.Count; i++)
                {
                    if (doubleWinMoves.Contains(singleWinMoves[i]))
                    {
                        PictureBox pb = this.Controls.Find("pbField" + singleWinMoves[i], true).FirstOrDefault() as PictureBox;
                        makeMove(pb, hint);
                        writeLog("Double double win block");
                        break;
                    }
                }
            }
            else if (isMiddleEmpty())
            { // Als het midden leeg is
                writeLog("Taking middle");
                takeMiddle(hint);
            }
            else if (isCornerEmpty())
            { // Als er een hoek leeg is
                writeLog("Taking corner");
                takeCorner(hint);
            }
            else // Als er een rand leeg is 
                try
                {
                    writeLog("Taking random");
                    takeRandom(hint);
                }
                // Als alle vakjes bezet zijn a.k.a gelijkspel
                catch (NullReferenceException)
                {
                    writeLog("Draw vs engine");
                    if (!computerMode)
                        MessageBox.Show("Gelijkspel");
                }



        }

        private int countWinChances(string player)
        {
            int counter = 0;
            int winChances = 0;
            int[] emptySpaces = new int[9];
            // Vull array emptyspaces  met indexes van alle lege vakjes
            for (int i = 1; i <= 9; i++)
            {
                if (boardState[i] == "empty")
                {
                    emptySpaces[counter] = i;
                    counter += 1;
                }
            }

            string[] realboard = (string[])boardState.Clone(); // Kopie van bord status, zodat het bord hersteld kan worden na de 'fake' moves
            // Voor elk leeg vakje maak een 'fake' move
            for (int x = 0; x <= counter; x++)
            {
                boardState = (string[])realboard.Clone(); // Herstel het bord
                boardState[emptySpaces[x]] = player;
                // Voor elke win positie
                // Voor elke draaing van het bord
                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        string[] board = turnBoard(i);
                        // Als er in deze situatie een winpositie is 
                        if (board[winPositions[j, 0]] == board[winPositions[j, 1]] && board[winPositions[j, 1]] == board[winPositions[j, 2]] && board[winPositions[j, 0]] != "empty")
                        {
                            boardState = (string[])realboard.Clone(); // Herstel het bord
                            winChances += 1;
                        }
                    }
                } // einde eerste for
                //} // einde 2de for
                boardState = (string[])realboard.Clone(); // Herstel het bord
            } // einde 3de for
            return winChances;
        }

        // Geeft een array terug met de nummers van alle lege vakjes
        private int[] getEmpty()
        {
            int counter = 0;
            int[] emptySpaces = new int[9];
            for (int i = 1; i <= 9; i++)
            {
                if (boardState[i] == "empty")
                {
                    emptySpaces[counter] = i;
                    counter += 1;
                }
            }
            return emptySpaces;
        }

        private void onDebug(object sender, EventArgs e)
        {
            computerMove();
        }



        // Computer zet functies
        // Midden   
        private bool isMiddleEmpty()
        {
            PictureBox pb = this.Controls.Find("pbField5", true).FirstOrDefault() as PictureBox;
            if (pb.Tag as string == "empty")
                return true;
            else
                return false;
        }

        private void takeMiddle(bool hint)
        {
            PictureBox pb = this.Controls.Find("pbField5", true).FirstOrDefault() as PictureBox;
            writeLog(turn + " - " + 5);
            makeMove(pb, hint);
        }

        // Hoeken
        private bool isCornerEmpty()
        {
            int[] corners = new int[4] { 1, 3, 7, 9 }; // lijst van hoeken
            PictureBox currentCorner;

            for (int i = 0; i < 4; i++)
            {
                currentCorner = this.Controls.Find("pbField" + corners[i], true).FirstOrDefault() as PictureBox;
                if (currentCorner.Tag as string == "empty")
                {
                    return true;
                }
            }
            return false;
        }

        private void takeCorner(bool hint)
        {
            int counter = 0;
            int[] corners = new int[4] { 1, 3, 7, 9 };
            PictureBox[] emptyCorners = new PictureBox[4];
            int[] eCorners = new int[4];
            PictureBox currentCorner;
            PictureBox pb;

            for (int i = 0; i < 4; i++)
            {
                currentCorner = this.Controls.Find("pbField" + corners[i], true).FirstOrDefault() as PictureBox;
                if (currentCorner.Tag as string == "empty")
                {
                    emptyCorners[counter] = currentCorner;
                    eCorners[counter] = corners[i];
                    counter += 1;
                }
            }
            int r = random.Next(counter);
            writeLog(turn + " - " + eCorners[r]);
            pb = emptyCorners[r];
            makeMove(pb, hint);
        }

        // Random vakje
        private void takeRandom(bool hint)
        {
            int counter = 0;
            int[] eFields = new int[9];
            PictureBox[] emptyFields = new PictureBox[10];
            PictureBox current;
            PictureBox pb;
            for (int i = 1; i <= 9; i++)
            {
                current = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
                if(current.Tag as string == "empty")
                {
                    eFields[counter] = i;
                    emptyFields[counter] = current;
                    counter++;
                }
            }
            int r = random.Next(counter);
            writeLog(turn + " - " + eFields[r]);
            pb = emptyFields[r];
            makeMove(pb, hint);
        }

        // Geeft de move terug waarmee 'player' kan winnen
        private int getWinMove(string player)
        {
            int counter = 0;
            int[] emptySpaces = new int[9];
            Array.Clear(emptySpaces, 0, emptySpaces.Length);
            for (int i = 1; i <= 9; i++)
            {
                if (boardState[i] == "empty")
                {
                    emptySpaces[counter] = i;
                    counter += 1;
                }
            }
            string[] realboard = (string[])boardState.Clone(); // Kopie van bord status, zodat het bord hersteld kan worden na de 'fake' moves
            // Voor elk leeg vakje
            for (int x = 0; x <= counter; x++)
            {
                boardState[emptySpaces[x]] = player;
                int bestMove = emptySpaces[x];
                // Voor elke win positie
                for (int j = 0; j < 3; j++)
                {
                    // Voor elke draaing van het bord
                    for (int i = 0; i < 4; i++)
                    {
                        string[] board = turnBoard(i);

                        if (board[winPositions[j, 0]] == board[winPositions[j, 1]] && board[winPositions[j, 1]] == board[winPositions[j, 2]] && board[winPositions[j, 0]] != "empty")
                        {
                            boardState = (string[])realboard.Clone(); // Herstel het bord
                            return bestMove;
                        }
                    } // einde eerste for
                } // einde 2de for
                boardState = (string[])realboard.Clone(); // Herstel het bord
            } // einde 3de for
            return 0;
        }

        // Geeft de zetten waarmee 2 wincondities gamaakt kunnen worden
        private List<int> getDoubleWinMoves(string player)
        {
            List<int> doubleMoves = new List<int>();
            int counter = 0;
            int[] emptySpaces = new int[9];
            // Vull array emptyspaces  met indexes van alle lege vakjes
            for (int x = 1; x <= 9; x++)
            {
                if (boardState[x] == "empty")
                {
                    emptySpaces[counter] = x;
                    counter += 1;
                }
            }
            string[] realboard = (string[])boardState.Clone(); // Kopie van bord status, zodat het bord hersteld kan worden na de 'fake' moves
            int[] realEmpty = (int[])emptySpaces.Clone();
            // Voor elke fake move
            for (int i = 0; i < counter; i++)
            {
                emptySpaces = (int[])realEmpty.Clone(); // Herstel de lege vakjes
                boardState = (string[])realboard.Clone(); // Herstel het bord
                boardState[emptySpaces[i]] = player;
                if (countWinChances(player) > 1)
                {
                    doubleMoves.Add(emptySpaces[i]);
                }
                else { }
            }
            boardState = (string[])realboard.Clone();
            return doubleMoves;
        }

        // Geeft een lijst met alle moves die een winconditie kunnen maken
        private List<int> getSingleWinMoves(string player)
        {
            List<int> singleMoves = new List<int>();
            int counter = 0;
            int[] emptySpaces = new int[9];
            // Vull array emptyspaces  met indexes van alle lege vakjes
            for (int x = 1; x <= 9; x++)
            {
                if (boardState[x] == "empty")
                {
                    emptySpaces[counter] = x;
                    counter += 1;
                }
            }
            string[] realboard = (string[])boardState.Clone(); // Kopie van bord status, zodat het bord hersteld kan worden na de 'fake' moves
            int[] realEmpty = (int[])emptySpaces.Clone();
            // Voor elke fake move
            for (int i = 0; i < counter; i++)
            {
                emptySpaces = (int[])realEmpty.Clone(); // Herstel de lege vakjes
                boardState = (string[])realboard.Clone(); // Herstel het bord
                boardState[emptySpaces[i]] = player;
                if (countWinChances(player) > 0)
                {
                    singleMoves.Add(emptySpaces[i]);
                }
            }
            // Loop door singleMoves heen en kijk voor het lege vakje met getWinmove
            boardState = (string[])realboard.Clone();
            return singleMoves;
        }

        private void getDoubleBlockMove(string turn, bool hint = false) {
            List<int> doubleWinMoves = getDoubleWinMoves(notTurn);
            List<int> singleWinMoves = getSingleWinMoves(turn);
            PictureBox pb;

            string[] realboard = (string[])boardState.Clone(); // Kopie van bord status, zodat het bord hersteld kan worden na de 'fake' moves
            // Voor elke fake move die een winkans creeërt
            for (int i = 1; i < singleWinMoves.Count; i++)
            {
                boardState = (string[])realboard.Clone(); // Herstel het bord
                boardState[singleWinMoves[i]] = turn.ToUpper();
                // kijk op welk vakje de winkans gecreeërd wordt
                int empty = getWinMove(turn);
                // Als dit vakje niet voorkomt in de dubbele winkans maak de move
                if (! doubleWinMoves.Contains(empty))
                {
                    pb = this.Controls.Find("pbField" + singleWinMoves[i], true).FirstOrDefault() as PictureBox;
                    writeLog(turn + " - " + singleWinMoves[i]);
                    boardState = (string[])realboard.Clone(); // Herstel het bord
                    makeMove(pb, hint);
                    break;
                }

            }
        }

        private void readList(List<int> li)
        {
            string fullList = "";
            for (int i = 0; i < li.Count; i++)
            {
                fullList = fullList + "  " + li[i].ToString();
            }
            MessageBox.Show(fullList);
        }

        // Maakt de zet die doorgegeven is
        private void makeMove(PictureBox pb, bool hint)
        {
            if (!hint)
            {
                pb.Tag = turn.ToUpper();
                pb.Image = Image.FromFile(path + turn.ToLower() + ".png");
                updateBoardState();
                showWinner();
                switchTurns();
            }
            else if (hint)
            {
                pb.Image = null;
                pb.BackColor = Color.FromArgb(64, 249, 197);
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (!boardImported)
            {
                writeLog("Board reset");
                resetBoard();
            }
            if (rbComputer.Checked)
            {
                againstComputer = true;
                writeLog("Start vs computer");
            }
            else if (rbHuman.Checked)
            {
                againstComputer = false;
                writeLog("Start vs human");
            }

            if (computerBegin && againstComputer)
            {
                computerMove();
            }
            boardImported = false;
        }

        private void btnO_Click(object sender, EventArgs e)
        {
            computerBegin = true;
            btnO.BackColor = Color.Gray;
            btnX.BackColor = beginColor;
        }

        private void btnX_Click(object sender, EventArgs e)
        {
            computerBegin = false;
            btnX.BackColor = Color.Gray;
            btnO.BackColor = beginColor;
        }

        private void switchTurns()
        {
            if (turn == "X")
            {
                turn = "O";
                notTurn = "X";
            }
            else
            {
                turn = "X";
                notTurn = "O";
            }
            lblTurn.Text = turn;
        }
        private void resetBoard()
        {
            turn = "X";
            notTurn = "O";
            for (int i = 1; i <= 9; i++)
            {
                PictureBox pb = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
                pb.Image = Image.FromFile(path + "empty.png");
                allFields[i] = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
                pb.Tag = "empty";
            }
            updateBoardState();
        }

        // Schrijft naar de log
        private void writeLog(string log)
        {
            lbLog.Items.Add(log);
        }
        private void btnComputerMode_Click(object sender, EventArgs e)
        {
            if (computerMode){
                computerMode = false;
            }
            else {
                computerMode = true;
            }
            Button currentSender = sender as Button;
            lblGameCount.Visible = true;
            int gameCounter = 0;
            int speed = Convert.ToInt32(tbSpeed.Text);
            resetBoard();
            while (computerMode)
            {
                if (!boardState.Contains("empty") || getWinner() != "")
                {
                    gameCounter++;
                    lblGameCount.Text = "Games: " + gameCounter;
                    resetBoard();
                    lbLog.Items.Clear();
                }
                if ((currentSender.Tag as string) != "OKMON")
                {
                    takeRandom(false);
                }
                else {
                    computerMove();
                }
                Thread.Sleep(speed);
                Application.DoEvents();
                computerMove();
                Thread.Sleep(speed);
                Application.DoEvents();
            }
        }
        /*
        Importeren van een bord
        format: 
        x = X, 
        o = O, 
        e = empty
        */
        private void btnImport_Click(object sender, EventArgs e)
        {
            if (!tbImport.Visible)
            {
                tbImport.Visible = true;
            }
            else
            {
                if (tbImport.Text.Length != 9) {
                    MessageBox.Show("Ongeldig aantal karakters.");
                }
                else
                {
                    boardImported = true;
                    int countX = 0;
                    int countO = 0;
                    for (int i = 1; i <= 9; i++)
                    {
                        string sign = tbImport.Text.Substring(i - 1, 1);
                        if (sign.ToUpper() != "X" && sign.ToUpper() != "O")
                        {
                            sign = sign.ToUpper();
                            sign = "empty";
                        }
                        if (sign.ToUpper() == "X")
                        {
                            sign = sign.ToUpper();
                            countX++;
                        }
                        else if (sign.ToUpper() == "O")
                        {
                            countO++;
                        }
                        PictureBox pb = this.Controls.Find("pbField" + i, true).FirstOrDefault() as PictureBox;
                        pb.Image = Image.FromFile(path + sign.ToLower() + ".png");
                        pb.Tag = sign;

                    }
                    if (countX > countO)
                    {
                        turn = "O";
                        notTurn = "X";
                    }
                    else
                    {
                        turn = "X";
                        notTurn = "O";
                    }
                    lblTurn.Text = turn;
                    updateBoardState();
                }   
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string export = "";
            for (int i = 1; i <= 9; i++)
            {
                if (boardState[i] != "empty")
                {
                    export += boardState[i];
                }
                else
                {
                    export += "e";
                }
            }
            try{
                Clipboard.SetText(export); // Kopieert de bord status naar het je clipbord
            }
            catch (ArgumentNullException){}

        }

        private void btnHint_Click(object sender, EventArgs e)
        {
            try{
                computerMove(true);
            }
            catch (NullReferenceException){}
        }

        private void btnDeveloper_Click(object sender, EventArgs e)
        {
            lblDelay.Visible = true;
            btnComputerMode.Visible = true;
            btnOkmonBattle.Visible = true;
            tbSpeed.Visible = true;
            btnDeveloper.Visible = false;
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            lbLog.Items.Clear();
        }
    }
}
