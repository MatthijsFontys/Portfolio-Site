Hoe open je het spel? :
	Pak de zip file uit op de gewenste locatie.
	Om het spel te spelen start/dubbelklik 'Okmon engine.exe'
	
De OKMON engine is een egine die boter kaas en eieren kan spelen.
Ook kan je de engine gebruiken om lokaal tegen andere mensen te spelen.
De engine is uitgebreid met wat extra functies,
zo kan je als je op developer mode drukt de engine tegen zichzelf laten spelen of tegen een computer die alleen random moves maakt

De format van het importeren van een game is:
x/X = X
o/O = O
e/E = Leeg vakje
Je moet dus 9 letters invoeren die het bord simuleren.
bijv: xxoooxxxo is:
					XXO
					OOX
					XXO
			
O.K.M.O.N
Opgeven kan morgen ook nog!
